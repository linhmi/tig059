/**
 * The Main class - MainGui is in this package.
 */

package se.itu.game.main;
